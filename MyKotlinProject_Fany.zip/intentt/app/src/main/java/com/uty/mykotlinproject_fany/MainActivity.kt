package com.uty.mykotlinproject_fany

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_main.*
import android.widget.Button as Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val proses = findViewById<Button>(R.id.saveBtn)
        val nama = findViewById<EditText>(R.id.nama)
        val nim = findViewById<EditText>(R.id.nim)
        val nilai = findViewById<EditText>(R.id.nilai)

        //action of button
        saveBtn.setOnClickListener(){

            val Nama=nama.text.toString()
            val Nim=nim.text.toString()
            val Nilai=nilai.text.toString().toInt()

            intent= Intent(this,ActivityProses::class.java)
            intent.putExtra("Nama",Nama)
            intent.putExtra("Nim",Nim)
            intent.putExtra("Nilai",Nilai)

            startActivity(intent)
        }
    }
}
