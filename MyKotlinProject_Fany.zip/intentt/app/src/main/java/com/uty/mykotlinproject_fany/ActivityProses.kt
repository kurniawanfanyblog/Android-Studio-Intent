package com.uty.mykotlinproject_fany
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_proses.*
import androidx.appcompat.app.AppCompatActivity

class ActivityProses : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_proses)

        var intent = intent
        val Nama=intent.getStringExtra("Nama")
        val Nim=intent.getStringExtra("Nim")
        val Nilai=intent.getIntExtra("Nilai",0)


        val ket:String

        if (Nilai>=80){
            ket="Keterangan : Mendapat Nilai A  "
        }
        else if (Nilai>=60){
            ket="Keterangan : Mendapat Nilai B  "
        }
        else if (Nilai>=40){
            ket="Keterangan : Mendapat Nilai C  "
        }
        else if (Nilai>=20){
            ket="Keterangan : Mendapat Nilai D  "
        }
        else {
            ket="Keterangan : Nilai E  "
        }

        val hasil=findViewById<TextView>(R.id.out_nilai)
        hasil.text="Nama : "+Nama+"\nNim : "+Nim+"\nNilai Angka : "+Nilai+"\n"+ket

        val bundle: Bundle? =intent.extras
        val id= bundle?.get("id_value")
        val language=bundle?.get("language_value")


        btn_back.setOnClickListener(){
            onBackPressed()

        }

    }
}